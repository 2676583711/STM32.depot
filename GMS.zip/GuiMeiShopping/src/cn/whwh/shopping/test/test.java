package cn.whwh.shopping.test;

import java.util.Date;

import com.mysql.jdbc.Connection;

import cn.whwh.shopping.dao.UserDaoImpl;
import cn.whwh.shopping.db.ConnDB;
import cn.whwh.shopping.service.UserService;
import cn.whwh.shopping.service.UserServiceImpl;
import cn.whwh.shopping.vo.UserTB;

public class test {
	public static void main(String[] args) {
		/*private int id;
		private String userName;
		private String loginName;
		private String userPwd;
		private String email;
		private int sex; //0:�� 1:Ů
		private String facePic;
		private String hobby;
		private Date birthdate;
		private String remark;
		UserService userService  = new UserServiceImpl();
		UserTB userTB = new UserTB(1,"xiaoming","xiaoming","xiaoming","123",1,"xiaoming","",new Date(),"123");
		*/
		ConnDB connDB = new ConnDB();
		Connection conn = (Connection) connDB.getConn();
		System.out.println(conn);
		
		
		
	}
}
