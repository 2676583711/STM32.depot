package cn.whwh.shopping.vo;

public class OrderDetailsTB {
    private int id;
    private int orderId;
    private int goodsId;
    private int nums;
    private String remark;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(int goodsId) {
        this.goodsId = goodsId;
    }

    public int getNums() {
        return nums;
    }

    public void setNums(int nums) {
        this.nums = nums;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public OrderDetailsTB(int id, int orderId, int goodsId, int nums, String remark) {
        this.id = id;
        this.orderId = orderId;
        this.goodsId = goodsId;
        this.nums = nums;
        this.remark = remark;
    }

    public OrderDetailsTB() {
    }
}
