package cn.whwh.shopping.vo;

import java.util.Date;

/*
 * userTb��ʵ����
 */
public class UserTB {
	private int id;
	private String userName;
	private String loginName;
	private String userPwd;
	private String email;
	private int sex; //0:�� 1:Ů
	private String facePic;
	private String hobby;
	private Date birthdate;
	private String remark;

	public UserTB(){}

	public UserTB(int id, String userName, String loginName, String userPwd,
			String email, int sex, String facePic, String hobby,
			Date birthdate, String remark) {
		super();
		this.id = id;
		this.userName = userName;
		this.loginName = loginName;
		this.userPwd = userPwd;
		this.email = email;
		this.sex = sex;
		this.facePic = facePic;
		this.hobby = hobby;
		this.birthdate = birthdate;
		this.remark = remark;
	}
	
	public UserTB(String userName, String loginName, String userPwd,
			String email, int sex, String facePic, String hobby,
			Date birthdate, String remark) {
		super();
		this.userName = userName;
		this.loginName = loginName;
		this.userPwd = userPwd;
		this.email = email;
		this.sex = sex;
		this.facePic = facePic;
		this.hobby = hobby;
		this.birthdate = birthdate;
		this.remark = remark;
	}
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getSex() {
		return sex;
	}

	public void setSex(int sex) {
		this.sex = sex;
	}

	public String getFacePic() {
		return facePic;
	}

	public void setFacePic(String facePic) {
		this.facePic = facePic;
	}

	public String getHobby() {
		return hobby;
	}

	public void setHobby(String hobby) {
		this.hobby = hobby;
	}

	public Date getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "UserTB [id=" + id + ", userName=" + userName + ", loginName="
				+ loginName + ", userPwd=" + userPwd + ", email=" + email
				+ ", sex=" + sex + ", facePic=" + facePic + ", hobby=" + hobby
				+ ", birthdate=" + birthdate + ", remark=" + remark + "]";
	}
	
	
}
