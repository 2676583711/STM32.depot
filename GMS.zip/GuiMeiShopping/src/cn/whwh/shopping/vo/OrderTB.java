package cn.whwh.shopping.vo;

import java.util.Date;

public class OrderTB {
    private int id;
    private int userId;
    private Date orderTime;
    private String addressee;
    private String direction;
    private String tel;
    private int status;
    private String remark;

    @Override
    public String toString() {
        return "OrderTB{" +
                "id=" + id +
                ", userId=" + userId +
                ", orderTime=" + orderTime +
                ", addressee='" + addressee + '\'' +
                ", direction='" + direction + '\'' +
                ", tel='" + tel + '\'' +
                ", status=" + status +
                ", remark='" + remark + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Date getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(Date orderTime) {
        this.orderTime = orderTime;
    }

    public String getAddressee() {
        return addressee;
    }

    public void setAddressee(String addressee) {
        this.addressee = addressee;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public OrderTB() {
    }

    public OrderTB(int id, int userId, Date orderTime, String addressee, String direction, String tel, int status, String remark) {
        this.id = id;
        this.userId = userId;
        this.orderTime = orderTime;
        this.addressee = addressee;
        this.direction = direction;
        this.tel = tel;
        this.status = status;
        this.remark = remark;
    }
    public OrderTB(int userId, Date orderTime, String addressee, String direction, String tel, int status, String remark) {
        this.userId = userId;
        this.orderTime = orderTime;
        this.addressee = addressee;
        this.direction = direction;
        this.tel = tel;
        this.status = status;
        this.remark = remark;
    }
}
