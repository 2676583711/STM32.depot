package cn.whwh.shopping.vo;

public class GoodsTB {

	private int id;  
	private int goodsTypeId;  //��Ʒ�����
	private String goodsName;
	private double unitPrice;
	private double discount;  //�Żݼ�
	private double freight; //�˷�
	private int stock; //���
	private String location; //���ڵ�
	private String goodsPic; //��ƷͼƬ·��
	private String remark;
	
	public GoodsTB() {
		super();
	}

	public GoodsTB(int id, int goodsTypeId, String goodsName, double unitPrice,
			double discount, double freight, int stock, String location,
			String goodsPic, String remark) {
		super();
		this.id = id;
		this.goodsTypeId = goodsTypeId;
		this.goodsName = goodsName;
		this.unitPrice = unitPrice;
		this.discount = discount;
		this.freight = freight;
		this.stock = stock;
		this.location = location;
		this.goodsPic = goodsPic;
		this.remark = remark;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getGoodsTypeId() {
		return goodsTypeId;
	}

	public void setGoodsTypeId(int goodsTypeId) {
		this.goodsTypeId = goodsTypeId;
	}

	public String getGoodsName() {
		return goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getFreight() {
		return freight;
	}

	public void setFreight(double freight) {
		this.freight = freight;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getGoodsPic() {
		return goodsPic;
	}

	public void setGoodsPic(String goodsPic) {
		this.goodsPic = goodsPic;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "GoodsTB [id=" + id + ", goodsTypeId=" + goodsTypeId
				+ ", goodsName=" + goodsName + ", unitPrice=" + unitPrice
				+ ", discount=" + discount + ", freight=" + freight
				+ ", stock=" + stock + ", location=" + location + ", goodsPic="
				+ goodsPic + ", remark=" + remark + "]";
	}

	
}
