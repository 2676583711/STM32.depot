package cn.whwh.shopping.vo;
/*
 * ���ﳵ����ƷVO
 */
public class GoodsCarVo {
	private String goodsName;
	private double unitPrice;
	private double discount;
	private int num; //��Ʒ����
	
	public GoodsCarVo(){}

	public GoodsCarVo(String goodsName, double unitPrice, double discount,
			int num) {
		super();
		this.goodsName = goodsName;
		this.unitPrice = unitPrice;
		this.discount = discount;
		this.num = num;
	}

	public String getGoodsName() {
		return goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	@Override
	public String toString() {
		return "GoodsCarVo [goodsName=" + goodsName + ", unitPrice="
				+ unitPrice + ", discount=" + discount + ", num=" + num + "]";
	}
	
	
}
