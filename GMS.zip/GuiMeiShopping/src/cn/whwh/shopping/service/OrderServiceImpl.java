package cn.whwh.shopping.service;

import cn.whwh.shopping.dao.OrderDaoImpl;

public class OrderServiceImpl extends OrderDaoImpl implements OrderService {
}
