package cn.whwh.shopping.service;

import cn.whwh.shopping.dao.UserDaoImpl;

public class UserServiceImpl extends UserDaoImpl implements UserService{

}
