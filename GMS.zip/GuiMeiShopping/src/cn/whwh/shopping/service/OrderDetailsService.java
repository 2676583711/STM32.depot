package cn.whwh.shopping.service;

import cn.whwh.shopping.dao.OrderDetailsDao;

public interface OrderDetailsService extends OrderDetailsDao {
}
