package cn.whwh.shopping.service;

import cn.whwh.shopping.dao.GoodsDaoImpl;

public class GoodsServiceImpl extends GoodsDaoImpl implements GoodsService{

}
