package cn.whwh.shopping.service;

import cn.whwh.shopping.dao.GoodsDao;

public interface GoodsService extends GoodsDao{

}
