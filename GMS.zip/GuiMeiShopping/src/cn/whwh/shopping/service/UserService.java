package cn.whwh.shopping.service;

import cn.whwh.shopping.dao.UserDao;

public interface UserService extends UserDao{
	
}
