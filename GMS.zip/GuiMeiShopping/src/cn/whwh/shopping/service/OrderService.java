package cn.whwh.shopping.service;

import cn.whwh.shopping.dao.OrderDao;

public interface OrderService extends OrderDao {
}
