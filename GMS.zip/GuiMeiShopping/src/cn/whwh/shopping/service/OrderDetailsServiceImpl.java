package cn.whwh.shopping.service;

import cn.whwh.shopping.dao.OrderDetailsDaoImpl;

public class OrderDetailsServiceImpl extends OrderDetailsDaoImpl implements OrderDetailsService {
}
