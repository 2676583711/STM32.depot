package cn.whwh.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.whwh.shopping.service.UserService;
import cn.whwh.shopping.service.UserServiceImpl;
import cn.whwh.shopping.vo.UserTB;

public class UserLoginServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request,response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		
		String loginName = request.getParameter("login").trim();
		String userPwd = request.getParameter("pwd").trim();
		
		UserService userService = new UserServiceImpl();
		String page = "";
		UserTB user = userService.login(loginName, userPwd);
		if(user != null){
			//��¼�ɹ�
			HttpSession session = request.getSession();
			session.setAttribute("user", user);
			page = "login_success.jsp";
		}else{
			//��¼ʧ��
			request.setAttribute("msg", "�û����������");
			page = "login.jsp";
		}
		request.getRequestDispatcher(page).forward(request, response);
	}

}
