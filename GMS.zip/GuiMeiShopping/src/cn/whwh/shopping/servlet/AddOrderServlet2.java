package cn.whwh.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.whwh.shopping.service.OrderDetailsService;
import cn.whwh.shopping.service.OrderDetailsServiceImpl;
import cn.whwh.shopping.service.OrderService;
import cn.whwh.shopping.service.OrderServiceImpl;
import cn.whwh.shopping.vo.GoodsCarVo;
import cn.whwh.shopping.vo.OrderDetailsTB;
import cn.whwh.shopping.vo.OrderTB;
import cn.whwh.shopping.vo.UserTB;

public class AddOrderServlet2 extends HttpServlet {

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doGet(request, response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        //��ȡ�����ջ�������,�绰,��ַ
        String username = request.getParameter("username");
        String address = request.getParameter("address");
        String tel = request.getParameter("telnumber");
        //��ȡ�û�
        HttpSession session = request.getSession();
        UserTB userTB = (UserTB) session.getAttribute("user");

        OrderTB orderTB = new OrderTB(userTB.getId(),new Date(),address,username,tel,0,null);

        OrderService orderService = new OrderServiceImpl();
        //���Ӷ���
        int orderId = orderService.addOrder(orderTB);
        orderService.getOrderByOederId(userTB.getId());
        ArrayList<OrderDetailsTB> orderDetailsList = new ArrayList<OrderDetailsTB>();
        Map<Integer,GoodsCarVo> shoppingCar = (Map<Integer,GoodsCarVo>)session.getAttribute("shoppingCar");

        Set<Integer> scKey = shoppingCar.keySet();
        Iterator<Integer> it =  scKey.iterator();
        while (it.hasNext()){
            int key = it.next();
            GoodsCarVo goodsCarVO = shoppingCar.get(key);
            OrderDetailsTB orderDetailsTB = new OrderDetailsTB();
            orderDetailsTB.setOrderId(orderId);
            orderDetailsTB.setGoodsId(key);
            orderDetailsTB.setNums(goodsCarVO.getNum());
            orderDetailsList.add(orderDetailsTB);
        }
        OrderDetailsService orderDetailsService = new OrderDetailsServiceImpl();
        Boolean n = orderDetailsService.addOrderDetails(orderDetailsList);
        System.out.println(n);
	}

}
