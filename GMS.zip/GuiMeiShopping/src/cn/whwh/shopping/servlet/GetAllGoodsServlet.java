package cn.whwh.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.whwh.shopping.service.GoodsService;
import cn.whwh.shopping.service.GoodsServiceImpl;
import cn.whwh.shopping.vo.GoodsTB;

public class GetAllGoodsServlet extends HttpServlet {

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		
		System.out.println("�Զ����� GetAllGoodsServlet");
		
		//����GoodsService�е�getAllGoods()��ȡ������Ʒ�б�
		GoodsService goodsService = new GoodsServiceImpl();
		ArrayList<GoodsTB> goodsList = goodsService.getAllGoods();
		
		//����Ʒ�б� ����application
		ServletContext application = config.getServletContext();
		application.setAttribute("goodsList", goodsList);
	}

}
