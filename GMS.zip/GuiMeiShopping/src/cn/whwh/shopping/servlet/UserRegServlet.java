package cn.whwh.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.whwh.shopping.service.UserService;
import cn.whwh.shopping.service.UserServiceImpl;
import cn.whwh.shopping.vo.UserTB;

public class UserRegServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request,response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		//���û�ע������л�ȡ�û���д����Ϣ
		String fname = request.getParameter("fname").trim();
		String lname = request.getParameter("lname").trim();
		String userName = lname + fname;
		String loginName = request.getParameter("sname").trim();
		String userPwd = request.getParameter("pass").trim();
		String email = request.getParameter("email").trim();
		String pageSex = request.getParameter("gender");
		int sex = pageSex.equals("��") ? 0 : 1;
		String[] hobbys = request.getParameterValues("hobby");
		String hobby = "";
		for(String s : hobbys){
			hobby += s + ",";
		}
		int year = Integer.parseInt(request.getParameter("nYear"));
		int month = Integer.parseInt(request.getParameter("nMonth"));
		int day = Integer.parseInt(request.getParameter("nDay"));
		Date birthdate = new Date(year,month,day);
		
		//ʹ�û�ȡ�����û���Ϣ������һ��UserTB�����û�����
		UserTB user = new UserTB();
		user.setUserName(userName);
		user.setLoginName(loginName);
		user.setUserPwd(userPwd);
		user.setEmail(email);
		user.setSex(sex);
		user.setFacePic(null);
		user.setHobby(hobby);
		user.setBirthdate(birthdate);
		user.setRemark(null);
		
		//����service�е�addUser()������д�����ݿ�
		UserService userService = new UserServiceImpl();
		String page = "";
		if(userService.addUser(user)){
			//ע��ɹ�����תҳ�浽ע��ɹ�ҳ��
			page = "/register_success.jsp";
		}else{
			//ע��ʧ�ܣ�����ע��ҳ��
			request.setAttribute("msg", "��Ϣ����ע��ʧ�ܣ����飡");
			page = "/register.jsp";
		}
		//��ת
		request.getRequestDispatcher(page).forward(request, response);
	}

}
