package cn.whwh.shopping.dao;

import cn.whwh.shopping.vo.OrderDetailsTB;

import java.util.ArrayList;

public interface OrderDetailsDao {


    //添加订单详情
    public boolean addOrderDetails(ArrayList<OrderDetailsTB> orderDetailsList);

    //根据订单编号查询订单详情
    public ArrayList<OrderDetailsTB> getOrderDetailsByOrderId(int orderId);

}
