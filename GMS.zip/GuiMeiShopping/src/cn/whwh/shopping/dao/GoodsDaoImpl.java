package cn.whwh.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import cn.whwh.shopping.db.ConnDB;
import cn.whwh.shopping.vo.GoodsTB;

public class GoodsDaoImpl extends ConnDB implements GoodsDao{

	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	@Override
	public ArrayList<GoodsTB> getAllGoods() {
		ArrayList<GoodsTB> goodsList = new ArrayList<GoodsTB>();
		
		conn = this.getConn();
		try {
			ps = conn.prepareStatement("select * from goodstb");
			rs = ps.executeQuery();
			while(rs.next()){
				GoodsTB goods = new GoodsTB(rs.getInt(1), rs.getInt(2), 
						rs.getString(3), rs.getDouble(4), rs.getDouble(5),
						rs.getDouble(6), rs.getInt(7), rs.getString(8),
						rs.getString(9), rs.getString(10));
				goodsList.add(goods);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeConn(conn);
		}
		
		return goodsList;
	}

	@Override
	public GoodsTB getGoodsInfoById(int id) {
		GoodsTB goods = null;
		conn = this.getConn();
		try {
			ps = conn.prepareStatement("select * from goodstb where id = ?");
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if(rs.next()){
				goods = new GoodsTB(rs.getInt(1), rs.getInt(2), 
						rs.getString(3), rs.getDouble(4), rs.getDouble(5),
						rs.getDouble(6), rs.getInt(7), rs.getString(8),
						rs.getString(9), rs.getString(10));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeConn(conn);
		}
		return goods;
	}

}
