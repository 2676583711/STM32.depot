package cn.whwh.shopping.dao;

import cn.whwh.shopping.db.ConnDB;
import cn.whwh.shopping.vo.OrderDetailsTB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class OrderDetailsDaoImpl extends ConnDB implements OrderDetailsDao {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;


    //添加订单详情
    public boolean addOrderDetails(ArrayList<OrderDetailsTB> orderDetailsList){
        Boolean flag = false;
        conn = this.getConn();
        try {
            conn.setAutoCommit(false);
            ps = conn.prepareStatement("insert into OrderDetails(orderid,goodsid,nums,remark) values(?,?,?,?) ");
            for (int x = 0;x<orderDetailsList.size();x++){
                OrderDetailsTB orderDetailsTB = orderDetailsList.get(x);
                ps.setInt(1,orderDetailsTB.getOrderId());
                ps.setInt(2,orderDetailsTB.getGoodsId());
                ps.setInt(3,orderDetailsTB.getNums());
                ps.setString(4,orderDetailsTB.getRemark());
                ps.executeUpdate();
            }
            conn.commit();
            flag = true;
        } catch (Exception e) {
            e.printStackTrace();
            try {
                conn.rollback();
            }catch (SQLException e2){
                e2.printStackTrace();
            }
        } finally {
            this.closeConn(conn);
        }
        return  flag;
    }

    //根据订单编号查询订单详情
    public ArrayList<OrderDetailsTB> getOrderDetailsByOrderId(int orderId){
        ArrayList<OrderDetailsTB> orderDetailsTBS = null;
        conn = this.getConn();
        try {
            ps = conn.prepareStatement("select * from OrderDetailsTB where orderid = ?");
            ps.setInt(1,orderId);
            rs = ps.executeQuery();
            while(rs.next()){
                OrderDetailsTB orderDetailsTB = new OrderDetailsTB();
                orderDetailsTB.setId(rs.getInt(1));
                orderDetailsTB.setOrderId(orderId);
                orderDetailsTB.setNums(rs.getInt(4));
                orderDetailsTB.setGoodsId((3));
                orderDetailsTB.setRemark(rs.getString(5));
                orderDetailsTBS.add(orderDetailsTB);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.closeConn(conn);
        }
        return orderDetailsTBS;
    }


}
