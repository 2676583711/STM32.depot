package cn.whwh.shopping.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import cn.whwh.shopping.db.ConnDB;
import cn.whwh.shopping.vo.UserTB;

public class UserDaoImpl extends ConnDB implements UserDao{

	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	
	@Override
	public boolean addUser(UserTB user) {
		boolean flag = false;
		conn = this.getConn();
		try {
			ps = conn.prepareStatement("insert into userTB(userName,loginName,userPwd," +
					"email,sex,facePic,hobby,birthdate,remark) values(?,?,?,?,?,?,?,?,?)");
			ps.setString(1, user.getUserName());
			ps.setString(2, user.getLoginName());
			ps.setString(3, user.getUserPwd());
			ps.setString(4, user.getEmail());
			ps.setInt(5, user.getSex());
			ps.setString(6, user.getFacePic());
			ps.setString(7, user.getHobby());
			ps.setDate(8, new Date(user.getBirthdate().getTime()));
			ps.setString(9, user.getRemark());
			
			int n = ps.executeUpdate();//ִ��sql
			if(n > 0){
				flag = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeConn(conn);
		}
		return flag;
	}

	@Override
	public UserTB login(String loginName, String userPwd) {
		UserTB user = null;
		
		conn = this.getConn();
		try {
			ps = conn.prepareStatement("select * from userTB where loginName = ? and userPwd = ?");
			ps.setString(1, loginName);
			ps.setString(2, userPwd);
			rs = ps.executeQuery();
			if(rs.next()){
				user = new UserTB(rs.getInt(1), rs.getString(2), rs.getString(3), 
						rs.getString(4), rs.getString(5), rs.getInt(6), 
						rs.getString(7), rs.getString(8), rs.getDate(9), rs.getString(10));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			this.closeConn(conn);
		}
		
		return user;
	}

}
