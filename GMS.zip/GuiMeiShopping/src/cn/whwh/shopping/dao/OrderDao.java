package cn.whwh.shopping.dao;

import cn.whwh.shopping.vo.OrderTB;

public interface OrderDao {

    public int addOrder(OrderTB order);

    public OrderTB getOrderById(int id);

    public OrderTB getOrderByOederId(int orderId);

}
