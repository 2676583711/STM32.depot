package cn.whwh.shopping.dao;

import cn.whwh.shopping.db.ConnDB;
import cn.whwh.shopping.vo.OrderTB;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class OrderDaoImpl extends ConnDB implements OrderDao {
    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    public int addOrder(OrderTB order){
        int id = 0;

        conn = this.getConn();
        try {
            conn .setAutoCommit(false);
            ps = conn.prepareStatement("insert into ordertb(userid,orderTime,addressee,direction,tel,status,remark) values(?,?,?,?,?,?,?)");
            ps.setInt(1,order.getUserId());
            ps.setDate(2, new Date(order.getOrderTime().getTime()));
            ps.setString(3,order.getAddressee());
            ps.setString(4,order.getDirection());
            ps.setString(5,order.getTel());
            ps.setInt(6,order.getStatus());
            ps.setString(7,order.getRemark());
            int n = ps.executeUpdate();
            if (n > 0 ){
                rs = ps.getGeneratedKeys();
                rs.last();
                id = rs.getInt(1);
            }
            conn.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.closeConn(conn);
        }
        return id;
    }

    public OrderTB getOrderById(int id){
        OrderTB orderTB = null;

        conn = this.getConn();

        try {
            ps = conn.prepareStatement("select * from ordertb where id = ?");
            ps.setInt(1,id);
            rs = ps.executeQuery();
            while (rs.next()){
                orderTB = new OrderTB(rs.getInt(1),rs.getInt(2),rs.getDate(3),
                        rs.getString(4),rs.getString(5),rs.getString(6),
                        rs.getInt(7),rs.getString(8));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.closeConn(conn);
        }
        return  orderTB;
    }

    public OrderTB getOrderByOederId(int orderId){
        OrderTB orderTB = null;

        conn = this.getConn();

        try {
            ps = conn.prepareStatement("select * from ordertb where orderId = ?");
            ps.setInt(1,orderId);
            rs = ps.executeQuery();
            while (rs.next()){
                orderTB = new OrderTB(rs.getInt(1),rs.getInt(2),rs.getDate(3),
                        rs.getString(4),rs.getString(5),rs.getString(6),
                        rs.getInt(7),rs.getString(8));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.closeConn(conn);
        }
        return  orderTB;

    }

}
