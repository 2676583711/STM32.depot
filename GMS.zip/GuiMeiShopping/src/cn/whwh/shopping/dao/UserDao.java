package cn.whwh.shopping.dao;

import cn.whwh.shopping.vo.UserTB;

public interface UserDao {

	//�û�ע��
	public boolean addUser(UserTB user);
	
	//�û���¼
	public UserTB login(String loginName,String userPwd);
}
